<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Biblioteca Evolução</title>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@700&family=Open+Sans:wght@400&display=swap" rel="stylesheet">
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Open Sans', sans-serif;
    }
    body, html {
        height: 100%;
        width: 100%;
        overflow: hidden;
    }
    body {
        background: url('imagem/biblioteca_fundo.webp') no-repeat center center/cover;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
    }
    body::before {
        content: "";
        position: absolute;
        inset: 0;
        background: rgba(0,0,0,0.6);
    }
    .conteudo {
        position: relative;
        z-index: 1;
        text-align: center;
        color: #fff;
        animation: slideUp 1.5s ease-out;
    }
    .conteudo h1 {
        font-family: 'Merriweather', serif;
        font-size: 3rem;
        margin-bottom: 15px;
    }
    .conteudo p {
        font-size: 1.2rem;
        opacity: 0.9;
    }
    @keyframes slideUp {
        from {
            transform: translateY(100px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
</style>
</head>
<body>

<div class="conteudo">
    <h1>Bem-Vindo(a) à Biblioteca Evolução</h1>
    <p>Explore conhecimento e descubra novas histórias</p>
</div>

</body>
</html>
